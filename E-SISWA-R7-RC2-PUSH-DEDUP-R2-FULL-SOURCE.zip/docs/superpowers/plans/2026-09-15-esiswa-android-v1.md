# E-SISWA Android v1.0.0 Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build an installable Android WebView wrapper and Android Studio source project for E-SISWA (SSD), using the supplied production Apps Script URL and logo.

**Architecture:** A single native Java Activity owns a hardened WebView, with a custom WebViewClient/WebChromeClient for camera permission, file chooser, downloads, popup windows, external links, navigation/back behavior, and session persistence. The web app remains the source of truth; the APK stores no Gemini key, spreadsheet credential, or E-SISWA user password.

**Tech Stack:** Java 17-compatible source, Android SDK compile/target 36, minSdk 26, Android Gradle Plugin 8.13.2, Gradle 8.13, platform WebView APIs only.

**Spec:** Approved in chat: app name `E-SISWA (SSD)`, package `id.sch.smpn4dumai.esiswa`, production URL supplied by user, supplied logo as launcher/splash icon, output APK + Android Studio source.

## Global Constraints

- Production URL must be exactly the user-supplied `/exec` deployment URL.
- App label must be `E-SISWA (SSD)`.
- Application ID must be `id.sch.smpn4dumai.esiswa`.
- No API key, spreadsheet ID, E-SISWA password, or session token may be hardcoded.
- Camera permission is granted to web content only for trusted Google Script origins and only after Android runtime permission is granted.
- Existing E-SISWA web behavior remains server-driven; the wrapper must not rewrite business logic.
- APK must support file selection/import, HTTP/blob downloads, popup WebViews, persistent cookies/session, and Android Back navigation.

---

### Task 1: Project contract and failing verification
**Files:** Create `tools/verify_project.py`.
- [ ] Write assertions for application ID, app name, URL, manifest permissions, camera permission bridge, file chooser, download handling, popup handling, Back navigation, logo resources, and secret scan.
- [ ] Run verification and confirm RED because the Android project files do not exist.

### Task 2: Android project and branding
**Files:** Create Gradle project files, manifest, resources, launcher icons, splash theme, offline page.
- [ ] Generate project skeleton targeting API 36/min 26.
- [ ] Generate density-specific launcher icons from the supplied logo without altering its design.
- [ ] Add `INTERNET`, `CAMERA`, network-state and legacy pre-29 download permissions only.
- [ ] Run verification; project-structure assertions must pass while Activity behavior assertions remain RED.

### Task 3: Hardened WebView Activity
**Files:** Create `MainActivity.java`, layout and supporting XML/assets.
- [ ] Configure JavaScript, DOM storage, cookies, safe mixed-content policy, zoom/view settings.
- [ ] Implement trusted-origin navigation and external intent routing.
- [ ] Implement runtime camera permission + WebChromeClient permission grant.
- [ ] Implement file chooser/import.
- [ ] Implement HTTP/HTTPS and blob/data download handling.
- [ ] Implement popup WebViews and Back navigation.
- [ ] Implement offline fallback and retry.
- [ ] Run verification and confirm all static behavior assertions pass.

### Task 4: Build metadata, README, and packaging
**Files:** Create `README.md`, `BUILDING.md`, signing helper/docs, source ZIP.
- [ ] Document Android Studio build/install and future URL/version updates.
- [ ] Generate a release signing keystore only if an Android build toolchain is available; never commit it.
- [ ] Build and verify APK if local Android SDK/Gradle tooling is available.
- [ ] Verify APK signature/package when built, then package source project separately.

### Task 5: Final audit
- [ ] Re-run `tools/verify_project.py` from the final source tree.
- [ ] Scan source/artifacts for API keys, passwords, tokens, accidental credentials, and unexpected URLs.
- [ ] Validate ZIP integrity and SHA-256 hashes.
- [ ] Report any environment-dependent limitation explicitly; never claim an APK was built unless the APK file exists and passes verification.
