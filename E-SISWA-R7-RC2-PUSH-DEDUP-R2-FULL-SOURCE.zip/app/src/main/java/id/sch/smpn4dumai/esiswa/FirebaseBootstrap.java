package id.sch.smpn4dumai.esiswa;

import android.content.Context;
import android.content.SharedPreferences;

import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;

import org.json.JSONObject;

public final class FirebaseBootstrap {
    private static final String PREFS = "esiswa_push";
    private static final String KEY_PROJECT_ID = "firebase_project_id";
    private static final String KEY_APP_ID = "firebase_app_id";
    private static final String KEY_API_KEY = "firebase_api_key";
    private static final String KEY_SENDER_ID = "firebase_sender_id";

    private FirebaseBootstrap() {}

    public static synchronized boolean ensureInitialized(Context context) {
        try {
            if (!FirebaseApp.getApps(context).isEmpty()) return true;
            SharedPreferences p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
            String projectId = p.getString(KEY_PROJECT_ID, "");
            String appId = p.getString(KEY_APP_ID, "");
            String apiKey = p.getString(KEY_API_KEY, "");
            String senderId = p.getString(KEY_SENDER_ID, "");
            if (blank(projectId) || blank(appId) || blank(apiKey) || blank(senderId)) return false;
            FirebaseOptions options = new FirebaseOptions.Builder()
                    .setProjectId(projectId.trim())
                    .setApplicationId(appId.trim())
                    .setApiKey(apiKey.trim())
                    .setGcmSenderId(senderId.trim())
                    .build();
            FirebaseApp.initializeApp(context, options);
            return !FirebaseApp.getApps(context).isEmpty();
        } catch (Exception ignored) {
            return false;
        }
    }

    public static synchronized boolean configure(Context context, String json) {
        try {
            JSONObject o = new JSONObject(json == null ? "{}" : json);
            String projectId = o.optString("projectId", "").trim();
            String appId = o.optString("applicationId", "").trim();
            String apiKey = o.optString("apiKey", "").trim();
            String senderId = o.optString("gcmSenderId", "").trim();
            if (blank(projectId) || blank(appId) || blank(apiKey) || blank(senderId)) return false;
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                    .putString(KEY_PROJECT_ID, projectId)
                    .putString(KEY_APP_ID, appId)
                    .putString(KEY_API_KEY, apiKey)
                    .putString(KEY_SENDER_ID, senderId)
                    .apply();
            return ensureInitialized(context);
        } catch (Exception ignored) {
            return false;
        }
    }

    public static boolean isConfigured(Context context) {
        SharedPreferences p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        return !blank(p.getString(KEY_PROJECT_ID, ""))
                && !blank(p.getString(KEY_APP_ID, ""))
                && !blank(p.getString(KEY_API_KEY, ""))
                && !blank(p.getString(KEY_SENDER_ID, ""));
    }

    private static boolean blank(String value) {
        return value == null || value.trim().isEmpty();
    }
}
