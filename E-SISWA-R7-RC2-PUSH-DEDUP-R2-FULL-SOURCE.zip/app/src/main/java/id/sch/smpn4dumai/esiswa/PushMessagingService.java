package id.sch.smpn4dumai.esiswa;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

import java.util.Map;
import java.util.Locale;
import java.security.MessageDigest;
import java.nio.charset.StandardCharsets;

public class PushMessagingService extends FirebaseMessagingService {
    public static final String CHANNEL_ATTENDANCE = "esiswa_attendance";
    public static final String CHANNEL_COACHING = "esiswa_coaching";
    public static final String CHANNEL_GENERAL = "esiswa_general";
    private static final String PREFS = "esiswa_push";
    private static final String KEY_TOKEN = "fcm_token";
    private static final int WEB_BADGE_NOTIFICATION_ID = 0x45534953;
    private static final String KEY_POPUP_DEDUPE_PREFIX = "popup_seen_";
    private static final long DUPLICATE_WINDOW_MS = 10L * 60L * 1000L;
    private static final String KEY_EVENT_DEDUPE_PREFIX = "pembinaan_event_seen_";
    private static final long EVENT_DEDUPE_WINDOW_MS = 24L * 60L * 60L * 1000L;

    @Override
    public void onNewToken(String token) {
        super.onNewToken(token);
        storeToken(this, token);
    }

    @Override
    public void onMessageReceived(RemoteMessage message) {
        super.onMessageReceived(message);
        Map<String, String> data = message.getData();
        RemoteMessage.Notification notificationPayload = message.getNotification();
        String title = firstNonBlank(data.get("title"),
                notificationPayload == null ? null : notificationPayload.getTitle(), "(SSD) SMPN4D");
        String body = firstNonBlank(data.get("body"),
                notificationPayload == null ? null : notificationPayload.getBody(),
                "Ada notifikasi baru dari (SSD) SMPN4D.");
        String kind = safe(data.get("kind"), "general");
        String view = safe(data.get("view"), "dashboard");
        String eventDedupeKey = safe(data.get("dedupeKey"), "");
        showLocalNotification(this, title, body, kind, view, message.getMessageId(), eventDedupeKey);
    }

    public static void showLocalNotification(Context context, String title, String body, String kind, String view, String messageId) {
        showLocalNotification(context, title, body, kind, view, messageId, "");
    }

    static void showLocalNotification(Context context, String title, String body, String kind, String view,
                                      String messageId, String eventDedupeKey) {
        if (context == null) return;
        ensureChannels(context);
        if (Build.VERSION.SDK_INT >= 33
                && context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        if (shouldSuppressDuplicatePopup(context, messageId)) return;

        int notificationId;
        boolean alert = true;
        String key = safe(eventDedupeKey, "").toLowerCase(Locale.ROOT);
        if (kind != null && kind.toLowerCase(Locale.ROOT).startsWith("pembinaan")
                && key.matches("[a-f0-9]{32}")) {
            EventNotificationDecision decision = preparePembinaanEventNotification(context, key, body);
            if (decision.suppress) return;
            notificationId = decision.notificationId;
            alert = decision.alert;
        } else {
            notificationId = messageId == null || messageId.trim().isEmpty()
                    ? (int) (System.currentTimeMillis() & 0x7fffffff)
                    : Math.abs(messageId.hashCode());
        }

        Intent open = new Intent(context, MainActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP)
                .putExtra("push_kind", kind)
                .putExtra("push_view", "notification_center");
        PendingIntent contentIntent = PendingIntent.getActivity(
                context,
                Math.abs((safe(kind, "general") + safe(view, "dashboard") + System.currentTimeMillis()).hashCode()),
                open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        String channelId = channelFor(kind);
        Notification notification = new Notification.Builder(context, channelId)
                .setSmallIcon(R.drawable.esiswa_notification_monochrome)
                .setContentTitle(safe(title, "(SSD) SMPN4D"))
                .setContentText(safe(body, "Ada notifikasi baru dari (SSD) SMPN4D."))
                .setStyle(new Notification.BigTextStyle().bigText(safe(body, "Ada notifikasi baru dari (SSD) SMPN4D.")))
                .setAutoCancel(true)
                .setShowWhen(true)
                .setNumber(1)
                .setOnlyAlertOnce(!alert)
                .setContentIntent(contentIntent)
                .build();

        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) nm.notify(notificationId, notification);
    }

    private static final class EventNotificationDecision {
        final boolean suppress;
        final int notificationId;
        final boolean alert;
        EventNotificationDecision(boolean suppress, int notificationId, boolean alert) {
            this.suppress = suppress;
            this.notificationId = notificationId;
            this.alert = alert;
        }
    }

    /**
     * Collapse role-specific variants of one server Pembinaan event on the same Android install.
     * If the generic student text arrives first, a later detailed text updates the existing
     * notification quietly. If detailed text arrives first, a later generic variant is ignored.
     */
    private static synchronized EventNotificationDecision preparePembinaanEventNotification(
            Context context, String eventKey, String body) {
        long now = System.currentTimeMillis();
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String storageKey = KEY_EVENT_DEDUPE_PREFIX + eventKey;
        boolean isDetailed = isDetailedPembinaanMessage(body);
        String previous = prefs.getString(storageKey, "");
        if (previous != null && !previous.isEmpty()) {
            String[] parts = previous.split("\\|", -1);
            if (parts.length == 3) {
                long previousAt = parseLong(parts[0]);
                boolean previousDetailed = "1".equals(parts[1]);
                int previousId = parseInt(parts[2]);
                if (previousAt > 0 && now >= previousAt && now - previousAt < EVENT_DEDUPE_WINDOW_MS) {
                    if (previousDetailed || !isDetailed) {
                        return new EventNotificationDecision(true, previousId, false);
                    }
                    // Upgrade generic -> detailed in-place, with no second alert sound/banner.
                    prefs.edit().putString(storageKey, now + "|1|" + previousId).apply();
                    return new EventNotificationDecision(false, previousId, false);
                }
            }
        }

        int notificationId = stableEventNotificationId(eventKey);
        prefs.edit().putString(storageKey, now + "|" + (isDetailed ? "1" : "0") + "|" + notificationId).apply();
        pruneOldEventNotificationKeys(prefs, now);
        return new EventNotificationDecision(false, notificationId, true);
    }

    private static boolean isDetailedPembinaanMessage(String body) {
        String b = body == null ? "" : body.trim().toLowerCase(Locale.ROOT);
        return !(b.equals("ada catatan pembinaan baru untuk kasus anda.")
                || b.equals("ada catatan pembinaan baru untuk kasus anda")
                || b.startsWith("kasus pembinaan anda dilanjutkan ke ")
                || b.startsWith("kasus pembinaan anda masuk status dalam pemantauan")
                || b.equals("kasus pembinaan anda telah ditandai selesai.")
                || b.equals("kasus pembinaan anda telah ditandai selesai"));
    }

    private static int stableEventNotificationId(String eventKey) {
        int id = ("pembinaan:" + eventKey).hashCode() & 0x3fffffff;
        if (id == 0 || id == WEB_BADGE_NOTIFICATION_ID) id = 0x13572468;
        return id;
    }

    private static void pruneOldEventNotificationKeys(SharedPreferences prefs, long now) {
        SharedPreferences.Editor editor = null;
        for (Map.Entry<String, ?> entry : prefs.getAll().entrySet()) {
            String name = entry.getKey();
            if (!name.startsWith(KEY_EVENT_DEDUPE_PREFIX)) continue;
            Object raw = entry.getValue();
            if (!(raw instanceof String)) {
                if (editor == null) editor = prefs.edit();
                editor.remove(name);
                continue;
            }
            String value = (String) raw;
            int sep = value.indexOf('|');
            long at = parseLong(sep > 0 ? value.substring(0, sep) : "");
            if (at <= 0 || now < at || now - at > 7L * EVENT_DEDUPE_WINDOW_MS) {
                if (editor == null) editor = prefs.edit();
                editor.remove(name);
            }
        }
        if (editor != null) editor.apply();
    }

    private static long parseLong(String value) {
        try { return Long.parseLong(value); } catch (Exception ignored) { return 0L; }
    }

    private static int parseInt(String value) {
        try { return Integer.parseInt(value); } catch (Exception ignored) { return 0; }
    }

    /** Suppress only repeat deliveries carrying the same stable FCM message ID. */
    static boolean shouldSuppressDuplicatePopup(Context context, String messageId) {
        if (context == null) return false;
        String stableId = messageId == null ? "" : messageId.trim();
        // Without a stable ID, do not guess that two messages are duplicates:
        // legitimate notifications can have the same title and body.
        if (stableId.isEmpty()) return false;

        long now = System.currentTimeMillis();
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String key = KEY_POPUP_DEDUPE_PREFIX + popupFingerprint(stableId);
        long previous = prefs.getLong(key, 0L);
        if (previous > 0L && (now < previous || now - previous < DUPLICATE_WINDOW_MS)) {
            return true;
        }

        SharedPreferences.Editor edit = prefs.edit();
        for (Map.Entry<String, ?> entry : prefs.getAll().entrySet()) {
            if (!entry.getKey().startsWith(KEY_POPUP_DEDUPE_PREFIX)) continue;
            Object value = entry.getValue();
            if (!(value instanceof Long)) {
                edit.remove(entry.getKey());
                continue;
            }
            long timestamp = (Long) value;
            if (now >= timestamp && now - timestamp >= DUPLICATE_WINDOW_MS) {
                edit.remove(entry.getKey());
            }
        }
        edit.putLong(key, now).apply();
        return false;
    }

    private static String popupFingerprint(String messageId) {
        try {
            byte[] digest = MessageDigest.getInstance("SHA-256")
                    .digest(messageId.getBytes(StandardCharsets.UTF_8));
            StringBuilder out = new StringBuilder(digest.length * 2);
            for (byte b : digest) out.append(String.format(Locale.ROOT, "%02x", b & 0xff));
            return out.toString();
        } catch (Exception ignored) {
            return Integer.toHexString(messageId.hashCode());
        }
    }

    private static String channelFor(String kind) {
        String k = kind == null ? "" : kind.toLowerCase();
        if (k.startsWith("attendance_") || k.equals("datang") || k.equals("pulang") || k.equals("pulang_cepat")) {
            return CHANNEL_ATTENDANCE;
        }
        if (k.startsWith("pembinaan")) return CHANNEL_COACHING;
        return CHANNEL_GENERAL;
    }

    public static void ensureChannels(Context context) {
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;

        NotificationChannel attendance = new NotificationChannel(
                CHANNEL_ATTENDANCE,
                context.getString(R.string.notification_channel_attendance),
                NotificationManager.IMPORTANCE_HIGH
        );
        attendance.setDescription("Notifikasi siswa masuk, pulang, dan pulang cepat.");
        attendance.setShowBadge(true);

        NotificationChannel coaching = new NotificationChannel(
                CHANNEL_COACHING,
                context.getString(R.string.notification_channel_coaching),
                NotificationManager.IMPORTANCE_DEFAULT
        );
        coaching.setDescription("Notifikasi catatan Pembinaan Siswa.");
        coaching.setShowBadge(true);

        NotificationChannel general = new NotificationChannel(
                CHANNEL_GENERAL,
                context.getString(R.string.notification_channel_general),
                NotificationManager.IMPORTANCE_DEFAULT
        );
        general.setDescription("Notifikasi umum Sistem Siswa Digital.");
        general.setShowBadge(true);

        nm.createNotificationChannel(attendance);
        nm.createNotificationChannel(coaching);
        nm.createNotificationChannel(general);
    }

    public static void updateWebBadgeNotification(Context context, String title, String body,
                                                  String kind, String view, int unreadCount,
                                                  boolean alert) {
        if (context == null) return;
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        if (unreadCount <= 0) {
            nm.cancel(WEB_BADGE_NOTIFICATION_ID);
            return;
        }
        ensureChannels(context);
        if (Build.VERSION.SDK_INT >= 33
                && context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        String safeTitle = safe(title, "(SSD) SMPN4D");
        String safeBody = safe(body, "Ada notifikasi baru yang belum dibaca.");
        Intent open = new Intent(context, MainActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP)
                .putExtra("push_kind", safe(kind, "pembinaan_new"))
                .putExtra("push_view", "notification_center");
        PendingIntent contentIntent = PendingIntent.getActivity(
                context, WEB_BADGE_NOTIFICATION_ID, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );
        Notification notification = new Notification.Builder(context, channelFor(kind))
                .setSmallIcon(R.drawable.esiswa_notification_monochrome)
                .setContentTitle(safeTitle)
                .setContentText(safeBody)
                .setStyle(new Notification.BigTextStyle().bigText(safeBody))
                .setAutoCancel(true)
                .setShowWhen(true)
                .setNumber(Math.max(1, unreadCount))
                .setOnlyAlertOnce(!alert)
                .setContentIntent(contentIntent)
                .build();
        nm.notify(WEB_BADGE_NOTIFICATION_ID, notification);
    }

    public static void storeToken(Context context, String token) {
        if (token == null || token.trim().isEmpty()) return;
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_TOKEN, token.trim()).apply();
    }

    public static String getCachedToken(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        return prefs.getString(KEY_TOKEN, "");
    }

    private static String firstNonBlank(String primary, String secondary, String fallback) {
        if (primary != null && !primary.trim().isEmpty()) return primary.trim();
        if (secondary != null && !secondary.trim().isEmpty()) return secondary.trim();
        return fallback;
    }

    private static String safe(String value, String fallback) {
        String out = value == null ? "" : value.trim();
        return out.isEmpty() ? fallback : out;
    }
}
