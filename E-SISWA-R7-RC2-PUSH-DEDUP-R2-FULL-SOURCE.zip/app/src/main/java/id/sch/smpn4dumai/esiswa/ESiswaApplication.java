package id.sch.smpn4dumai.esiswa;

import android.app.Application;

public class ESiswaApplication extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        FirebaseBootstrap.ensureInitialized(this);
        PushMessagingService.ensureChannels(this);
    }
}
