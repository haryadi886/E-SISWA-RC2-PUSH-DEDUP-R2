package id.sch.smpn4dumai.esiswa;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.DownloadManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.ActivityNotFoundException;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Message;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.provider.Settings;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowInsets;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.JavascriptInterface;
import android.webkit.MimeTypeMap;
import android.webkit.PermissionRequest;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.webkit.JavaScriptReplyProxy;
import androidx.webkit.WebMessageCompat;
import androidx.webkit.WebViewCompat;
import androidx.webkit.WebViewFeature;

import org.json.JSONObject;

import com.google.firebase.messaging.FirebaseMessaging;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class MainActivity extends Activity {
    public static final String START_URL = "https://script.google.com/a/macros/guru.smp.belajar.id/s/AKfycbyakrD5CIbaeZm7GH3jwn2ZGrpA_DBq6HYkOqLUaNI-g18L4GBzMctYVSYM7f9O7ZCzkQ/exec?page=login";

    private static final int REQ_FILE_CHOOSER = 1001;
    private static final int REQ_CAMERA = 1002;
    private static final int REQ_WRITE_STORAGE = 1003;
    private static final int REQ_NOTIFICATIONS = 1004;
    private static final long MAX_BLOB_BYTES = 50L * 1024L * 1024L;
    private static final long PRINT_STALE_TIMEOUT_MS = 8000L;

    private WebView webView;
    private ProgressBar progressBar;
    private View launchOverlay;
    private ValueCallback<Uri[]> filePathCallback;
    private PermissionRequest pendingWebPermission;
    private PendingDownload pendingDownload;
    private final Map<WebView, Dialog> popupDialogs = new LinkedHashMap<>();
    private final Map<WebView, Integer> popupBottomInsets = new LinkedHashMap<>();
    private final Map<WebView, Boolean> modernPrintBridge = new LinkedHashMap<>();
    private WebView pendingPrintWebView;
    private JavaScriptReplyProxy pendingPrintReplyProxy;
    private boolean pendingPrintLostFocus;
    private WebView pendingPrintSnapshotWebView;
    private long pendingPrintStartedAtMs;
    private static final String WEB_NOTIFICATION_PREFS = "esiswa_web_notification_state";
    private static final String KEY_LAST_WEB_BADGE_COUNT = "last_web_badge_count";
    // R7 / Android v1.1.3.5.6 — persistent login MUST live in native app storage.
    // Apps Script HTML can be served through changing googleusercontent origins,
    // therefore WebView localStorage alone is not a reliable trusted-device vault.
    private static final String AUTH_PERSIST_PREFS = "esiswa_android_persistent_auth";
    private static final String KEY_AUTH_REFRESH_TOKEN = "refresh_token";
    private static final String KEY_AUTH_EXPIRES_AT = "expires_at";
    private String cachedFcmToken = "";
    private String pendingPushKind = "";
    private String pendingPushView = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTheme(R.style.Theme_ESISWA);
        super.onCreate(savedInstanceState);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            getWindow().setNavigationBarContrastEnforced(false);
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            getWindow().setDecorFitsSystemWindows(true);
        }
        setContentView(R.layout.activity_main);

        progressBar = findViewById(R.id.progress);
        webView = findViewById(R.id.webView);
        launchOverlay = findViewById(R.id.launchOverlay);

        CookieManager.getInstance().setAcceptCookie(true);
        configureWebView(webView, false);
        PushMessagingService.ensureChannels(this);
        capturePushIntent(getIntent());
        requestNotificationPermissionIfNeeded();
        refreshFcmToken();

        if (savedInstanceState == null) {
            if (isNetworkAvailable()) {
                webView.loadUrl(START_URL);
            } else {
                showOffline(webView);
            }
        } else {
            webView.restoreState(savedInstanceState);
            webView.postDelayed(this::hideLaunchOverlay, 160);
        }
    }

    private void configureWebView(WebView target, boolean popup) {
        WebSettings settings = target.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setLoadsImagesAutomatically(true);
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(true);
        // Responsif mengikuti pola E-TAMU: wide viewport + overview mode + native initial scale,
        // tanpa memaksa ulang meta viewport halaman menjadi 0.88.
        settings.setTextZoom(96);
        target.setInitialScale(0);
        settings.setSupportZoom(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);
        settings.setSupportMultipleWindows(true);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            settings.setSafeBrowsingEnabled(true);
        }

        CookieManager.getInstance().setAcceptThirdPartyCookies(target, true);
        target.setWebViewClient(new ESiswaWebViewClient());
        target.setWebChromeClient(new ESiswaChromeClient(target));
        target.addJavascriptInterface(new DownloadBridge(this), "ESISWANative");
        configureNativePrint(target);
        if (!popup) {
            target.addJavascriptInterface(new PushBridge(), "ESISWAAndroidPush");
            configureNativeNotificationMirror(target);
        }
        target.setDownloadListener(new ESiswaDownloadListener(target));
        target.setOverScrollMode(View.OVER_SCROLL_NEVER);

        if (!popup && BuildConfig.DEBUG) {
            WebView.setWebContentsDebuggingEnabled(true);
        }
    }

    private boolean isTrustedWebOrigin(Uri uri) {
        if (uri == null || !"https".equalsIgnoreCase(uri.getScheme())) return false;
        String host = uri.getHost();
        if (host == null) return false;
        host = host.toLowerCase(Locale.ROOT);
        return host.equals("script.google.com")
                || host.equals("script.googleusercontent.com")
                || host.endsWith(".script.googleusercontent.com")
                || host.endsWith("-script.googleusercontent.com");
    }

    private boolean isTrustedCameraOrigin(Uri uri) {
        if (uri == null || !"https".equalsIgnoreCase(uri.getScheme())) return false;
        String host = uri.getHost();
        if (host == null) return false;
        host = host.toLowerCase(Locale.ROOT);
        return host.equals("script.google.com")
                || host.equals("script.googleusercontent.com")
                || host.endsWith(".script.googleusercontent.com")
                || host.endsWith("-script.googleusercontent.com");
    }

    private boolean openExternal(Uri uri) {
        if (uri == null) return false;
        try {
            Intent intent;
            if ("intent".equalsIgnoreCase(uri.getScheme())) {
                intent = Intent.parseUri(uri.toString(), Intent.URI_INTENT_SCHEME);
            } else {
                intent = new Intent(Intent.ACTION_VIEW, uri);
            }
            startActivity(intent);
            return true;
        } catch (Exception ignored) {
            Toast.makeText(this, "Tautan tidak dapat dibuka.", Toast.LENGTH_SHORT).show();
            return true;
        }
    }

    private void showOffline(WebView target) {
        target.loadUrl("file:///android_asset/offline.html");
    }

    private boolean isNetworkAvailable() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        if (cm == null) return false;
        NetworkCapabilities caps = cm.getNetworkCapabilities(cm.getActiveNetwork());
        return caps != null && (caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
                || caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)
                || caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)
                || caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN));
    }


    private void requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIFICATIONS);
        }
    }

    private void showPermissionSettingsDialog(String title, String message) {
        if (isFinishing()) return;
        new AlertDialog.Builder(this)
                .setTitle(title)
                .setMessage(message)
                .setNegativeButton("Nanti", null)
                .setPositiveButton("Buka Pengaturan", (dialog, which) -> {
                    try {
                        Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                        intent.setData(Uri.parse("package:" + getPackageName()));
                        startActivity(intent);
                    } catch (Exception ignored) {
                        toast("Pengaturan aplikasi tidak dapat dibuka.");
                    }
                })
                .show();
    }

    private void refreshFcmToken() {
        cachedFcmToken = PushMessagingService.getCachedToken(this);
        if (!FirebaseBootstrap.ensureInitialized(this)) return;
        try {
            FirebaseMessaging.getInstance().getToken().addOnCompleteListener(task -> {
                if (!task.isSuccessful() || task.getResult() == null) return;
                String token = task.getResult().trim();
                if (token.isEmpty()) return;
                cachedFcmToken = token;
                PushMessagingService.storeToken(this, token);
                deliverCachedFcmTokenToPage();
            });
        } catch (Exception ignored) {
            // Firebase belum terkonfigurasi / Play Services tidak tersedia: WebView tetap berfungsi normal.
        }
    }

    private void capturePushIntent(Intent intent) {
        if (intent == null) return;
        String kind = intent.getStringExtra("push_kind");
        String view = intent.getStringExtra("push_view");
        if (kind != null) pendingPushKind = kind.trim();
        if (view != null) pendingPushView = view.trim();
    }

    private void deliverCachedFcmTokenToPage() {
        if (webView == null || cachedFcmToken == null || cachedFcmToken.trim().isEmpty()) return;
        String js = "window.dispatchEvent(new CustomEvent('esiswa-fcm-token',{detail:{token:"
                + JSONObject.quote(cachedFcmToken.trim()) + "}}));";
        webView.post(() -> webView.evaluateJavascript(js, null));
    }

    private void deliverPendingPushOpenToPage() {
        if (webView == null || pendingPushKind == null || pendingPushKind.isEmpty()) return;
        String kind = pendingPushKind;
        String view = pendingPushView == null ? "" : pendingPushView;
        pendingPushKind = "";
        pendingPushView = "";
        String js = "window.dispatchEvent(new CustomEvent('esiswa-native-push-open',{detail:{kind:"
                + JSONObject.quote(kind) + ",view:" + JSONObject.quote(view) + "}}));";
        webView.post(() -> webView.evaluateJavascript(js, null));
    }

    public final class PushBridge {
        @JavascriptInterface
        public String getCachedFcmToken() {
            String token = cachedFcmToken;
            if (token == null || token.trim().isEmpty()) token = PushMessagingService.getCachedToken(MainActivity.this);
            return token == null ? "" : token;
        }

        @JavascriptInterface
        public String getDeviceId() {
            String id = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
            return id == null ? "" : id;
        }

        @JavascriptInterface
        public String getAppVersion() {
            return BuildConfig.VERSION_NAME;
        }

        @JavascriptInterface
        public String getPersistentSessionCredential() {
            try {
                SharedPreferences prefs = getSharedPreferences(AUTH_PERSIST_PREFS, Context.MODE_PRIVATE);
                String refreshToken = prefs.getString(KEY_AUTH_REFRESH_TOKEN, "");
                String expiresAt = prefs.getString(KEY_AUTH_EXPIRES_AT, "");
                if (refreshToken == null || refreshToken.trim().isEmpty()) return "";
                JSONObject out = new JSONObject();
                out.put("refreshToken", refreshToken.trim());
                out.put("expiresAt", expiresAt == null ? "" : expiresAt);
                return out.toString();
            } catch (Exception ignored) {
                return "";
            }
        }

        @JavascriptInterface
        public boolean savePersistentSessionCredential(String refreshToken, String expiresAt) {
            String token = refreshToken == null ? "" : refreshToken.trim();
            if (token.length() < 40 || token.length() > 500) return false;
            String exp = expiresAt == null ? "" : expiresAt.trim();
            // commit() sengaja dipakai agar credential benar-benar tersimpan sebelum
            // proses APK bisa ditutup oleh pengguna/OEM sesaat setelah login.
            return getSharedPreferences(AUTH_PERSIST_PREFS, Context.MODE_PRIVATE)
                    .edit()
                    .putString(KEY_AUTH_REFRESH_TOKEN, token)
                    .putString(KEY_AUTH_EXPIRES_AT, exp)
                    .commit();
        }

        @JavascriptInterface
        public boolean clearPersistentSessionCredential() {
            return getSharedPreferences(AUTH_PERSIST_PREFS, Context.MODE_PRIVATE)
                    .edit()
                    .remove(KEY_AUTH_REFRESH_TOKEN)
                    .remove(KEY_AUTH_EXPIRES_AT)
                    .commit();
        }

        @JavascriptInterface
        public boolean hasPersistentSessionCredential() {
            String token = getSharedPreferences(AUTH_PERSIST_PREFS, Context.MODE_PRIVATE)
                    .getString(KEY_AUTH_REFRESH_TOKEN, "");
            return token != null && token.trim().length() >= 40;
        }

        @JavascriptInterface
        public boolean isNativePushAvailable() {
            return true;
        }

        @JavascriptInterface
        public boolean isFirebaseConfigured() {
            return FirebaseBootstrap.isConfigured(MainActivity.this);
        }

        @JavascriptInterface
        public boolean configureFirebase(String json) {
            boolean configured = FirebaseBootstrap.configure(MainActivity.this, json);
            if (configured) {
                runOnUiThread(() -> {
                    refreshFcmToken();
                    // Beberapa perangkat OEM baru mengembalikan token sesaat setelah
                    // Firebase selesai diinisialisasi. Ulangi sekali tanpa mengganggu UI.
                    if (webView != null) webView.postDelayed(MainActivity.this::refreshFcmToken, 1500);
                });
            }
            return configured;
        }

        @JavascriptInterface
        public void requestFcmTokenRefresh() {
            runOnUiThread(MainActivity.this::refreshFcmToken);
        }

        @JavascriptInterface
        public String getNativePushStatus() {
            JSONObject out = new JSONObject();
            try {
                String token = cachedFcmToken;
                if (token == null || token.trim().isEmpty()) token = PushMessagingService.getCachedToken(MainActivity.this);
                boolean permissionGranted = Build.VERSION.SDK_INT < 33
                        || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
                NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
                boolean appNotificationsEnabled = nm == null || nm.areNotificationsEnabled();
                boolean attendanceChannelEnabled = true;
                if (nm != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    NotificationChannel ch = nm.getNotificationChannel(PushMessagingService.CHANNEL_ATTENDANCE);
                    attendanceChannelEnabled = ch == null || ch.getImportance() != NotificationManager.IMPORTANCE_NONE;
                }
                out.put("firebaseConfigured", FirebaseBootstrap.isConfigured(MainActivity.this));
                out.put("tokenPresent", token != null && !token.trim().isEmpty());
                out.put("permissionGranted", permissionGranted);
                out.put("appNotificationsEnabled", appNotificationsEnabled);
                out.put("attendanceChannelEnabled", attendanceChannelEnabled);
                out.put("appVersion", BuildConfig.VERSION_NAME);
            } catch (Exception e) {
                try { out.put("error", String.valueOf(e.getMessage())); } catch (Exception ignored) {}
            }
            return out.toString();
        }
    }


    private void hideLaunchOverlay() {
        if (launchOverlay == null || launchOverlay.getVisibility() != View.VISIBLE) return;
        launchOverlay.animate()
                .alpha(0f)
                .setDuration(120)
                .withEndAction(() -> {
                    launchOverlay.setVisibility(View.GONE);
                    launchOverlay.setAlpha(1f);
                })
                .start();
    }

    private void normalizeAppsScriptOuterFrame(WebView view, String url) {
        if (view == null || url == null) return;
        Uri uri;
        try { uri = Uri.parse(url); } catch (Exception ignored) { return; }
        if (!"script.google.com".equalsIgnoreCase(uri.getHost())) return;
        final String js = "(function(){"
                + "try{"
                + "var h=document.documentElement,b=document.body;"
                + "if(h){h.style.setProperty('width','100%','important');h.style.setProperty('height','100%','important');h.style.setProperty('min-height','100%','important');h.style.setProperty('margin','0','important');h.style.setProperty('padding','0','important');h.style.setProperty('overflow','hidden','important');}"
                + "if(b){b.style.setProperty('width','100%','important');b.style.setProperty('height','100%','important');b.style.setProperty('min-height','100%','important');b.style.setProperty('margin','0','important');b.style.setProperty('padding','0','important');b.style.setProperty('overflow','hidden','important');}"
                + "var fs=document.querySelectorAll('iframe');"
                + "for(var i=0;i<fs.length;i++){var f=fs[i];f.removeAttribute('height');f.style.setProperty('position','fixed','important');f.style.setProperty('inset','0','important');f.style.setProperty('top','0','important');f.style.setProperty('left','0','important');f.style.setProperty('right','0','important');f.style.setProperty('bottom','0','important');f.style.setProperty('width','100%','important');f.style.setProperty('height','100%','important');f.style.setProperty('min-height','100%','important');f.style.setProperty('max-height','100%','important');f.style.setProperty('margin','0','important');f.style.setProperty('padding','0','important');f.style.setProperty('border','0','important');f.style.setProperty('display','block','important');}"
                + "}catch(e){}"
                + "})();";
        view.evaluateJavascript(js, null);
    }

    private void scheduleAppsScriptOuterFrameNormalization(WebView view, String url) {
        normalizeAppsScriptOuterFrame(view, url);
        if (view == null) return;
        view.postDelayed(() -> normalizeAppsScriptOuterFrame(view, url), 250);
        view.postDelayed(() -> normalizeAppsScriptOuterFrame(view, url), 900);
    }

    private int resolveNavigationBarHeight() {
        int id = getResources().getIdentifier("navigation_bar_height", "dimen", "android");
        return id > 0 ? Math.max(getResources().getDimensionPixelSize(id), 0) : 0;
    }

    private void applyCameraPopupSafeArea(WebView popup, int bottomInset) {
        if (popup == null) return;
        int safeBottom = Math.max(Math.max(bottomInset, 0), resolveNavigationBarHeight());
        final String js = "(function(){"
                + "var b=document.getElementById('btns'),v=document.getElementById('video');"
                + "if(!b||!v||!document.body)return;"
                + "var t=(document.body.innerText||'').toUpperCase();if(t.indexOf('KAMERA')<0)return;"
                + "document.documentElement.style.setProperty('--esiswa-native-nav-bottom','" + safeBottom + "px');"
                + "var s=document.getElementById('esiswa-native-camera-safe-area');"
                + "if(!s){s=document.createElement('style');s.id='esiswa-native-camera-safe-area';document.head.appendChild(s);}"
                + "s.textContent='@media screen and (max-width:700px), screen and (max-height:1000px){'"
                + "+'html,body{height:auto!important;min-height:100dvh!important;overflow-y:auto!important;}'"
                + "+'body{padding-bottom:calc(var(--esiswa-native-nav-bottom,0px) + 24px)!important;scroll-padding-bottom:calc(var(--esiswa-native-nav-bottom,0px) + 24px)!important;}'"
                + "+'#video,video{max-height:calc(100dvh - 360px - var(--esiswa-native-nav-bottom,0px))!important;min-height:220px!important;height:auto!important;object-fit:cover!important;}'"
                + "+'#videoWrap{max-height:calc(100dvh - 360px - var(--esiswa-native-nav-bottom,0px))!important;overflow:hidden!important;border-radius:14px!important;}'"
                + "+'#btns,.btns{position:relative!important;z-index:5!important;flex-shrink:0!important;margin-bottom:calc(var(--esiswa-native-nav-bottom,0px) + 18px)!important;}'"
                + "+'}';"
                + "})();";
        popup.evaluateJavascript(js, null);
    }

    private void applyPopupSystemInsets(WebView popup, Window window) {
        if (popup == null || window == null) return;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.setDecorFitsSystemWindows(true);
        }
        popup.setOnApplyWindowInsetsListener((v, insets) -> {
            int bottom;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                bottom = insets.getInsets(WindowInsets.Type.navigationBars()).bottom;
            } else {
                bottom = insets.getSystemWindowInsetBottom();
            }
            int safeBottom = Math.max(Math.max(bottom, 0), resolveNavigationBarHeight());
            popupBottomInsets.put(popup, safeBottom);
            applyCameraPopupSafeArea(popup, safeBottom);
            return insets;
        });
        popupBottomInsets.put(popup, resolveNavigationBarHeight());
        popup.requestApplyInsets();
    }

    private java.util.Set<String> trustedPrintOrigins() {
        return new java.util.LinkedHashSet<>(Arrays.asList(
                "https://script.google.com",
                "https://script.googleusercontent.com",
                "https://*.script.googleusercontent.com",
                "https://*.googleusercontent.com"
        ));
    }

    private String nativePrintDocumentStartScript() {
        return "(function(){"
                + "if(window.__ESISWA_NATIVE_PRINT_V4_INSTALLED)return;"
                + "if(!window.ESISWAPrintNative||typeof window.ESISWAPrintNative.postMessage!=='function')return;"
                + "window.__ESISWA_NATIVE_PRINT_V4_INSTALLED=true;"
                + "function lightRequest(){return JSON.stringify({action:'print',title:document.title||'E-SISWA',baseUrl:document.baseURI||location.href||''});}"
                + "function snapshotRequest(){"
                + "var clone=document.documentElement?document.documentElement.cloneNode(true):null;"
                + "if(clone){try{var scripts=clone.querySelectorAll('script');for(var i=scripts.length-1;i>=0;i--){scripts[i].parentNode.removeChild(scripts[i]);}}catch(e){}}"
                + "return JSON.stringify({action:'snapshot',title:document.title||'E-SISWA',baseUrl:document.baseURI||location.href||'',printHtml:'<!doctype html>'+(clone?clone.outerHTML:'')});"
                + "}"
                + "window.ESISWAPrintNative.onmessage=function(event){"
                + "if(!event)return;"
                + "if(event.data==='afterprint'){try{window.dispatchEvent(new Event('afterprint'));}catch(e){}return;}"
                + "if(event.data==='request-snapshot'){try{window.ESISWAPrintNative.postMessage(snapshotRequest());}catch(e){}return;}"
                + "};"
                + "window.print=function(){try{window.ESISWAPrintNative.postMessage(lightRequest());}catch(e){}};"
                + "})();";
    }

    private void configureNativePrint(WebView target) {
        if (target == null) return;
        boolean modern = false;
        try {
            if (WebViewFeature.isFeatureSupported(WebViewFeature.WEB_MESSAGE_LISTENER)
                    && WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
                java.util.Set<String> origins = trustedPrintOrigins();
                WebViewCompat.addWebMessageListener(
                        target,
                        "ESISWAPrintNative",
                        origins,
                        (view, message, sourceOrigin, isMainFrame, replyProxy) -> {
                            if (message == null || message.getType() != WebMessageCompat.TYPE_STRING) return;
                            if (!isTrustedWebOrigin(sourceOrigin)) return;
                            String requestJson = message.getData();
                            PrintRequestData request = parseNativePrintRequest(requestJson);
                            runOnUiThread(() -> {
                                if (request.isSnapshot()) {
                                    startSnapshotPrint(view, request, replyProxy);
                                } else {
                                    startNativePrint(view, request, replyProxy);
                                }
                            });
                        }
                );
                WebViewCompat.addDocumentStartJavaScript(target, nativePrintDocumentStartScript(), origins);
                modern = true;
            }
        } catch (Exception ignored) {
            modern = false;
        }
        modernPrintBridge.put(target, modern);
        if (!modern) {
            target.addJavascriptInterface(new PrintBridge(target), "ESISWAPrint");
        }
    }

    private void installNativePrintBridge(WebView view) {
        if (view == null || Boolean.TRUE.equals(modernPrintBridge.get(view))) return;
        final String js = "(function(){"
                + "if(window.__ESISWA_NATIVE_PRINT_V3_LEGACY_INSTALLED)return;"
                + "if(!window.ESISWAPrint||typeof window.ESISWAPrint.printPage!=='function')return;"
                + "window.__ESISWA_NATIVE_PRINT_V3_LEGACY_INSTALLED=true;"
                + "window.print=function(){try{"
                + "var clone=document.documentElement?document.documentElement.cloneNode(true):null;"
                + "if(clone){var scripts=clone.querySelectorAll('script');for(var i=scripts.length-1;i>=0;i--){scripts[i].parentNode.removeChild(scripts[i]);}}"
                + "window.ESISWAPrint.printPage(document.title||'E-SISWA',document.baseURI||location.href||'','<!doctype html>'+(clone?clone.outerHTML:''));"
                + "}catch(e){}};"
                + "})();";
        view.evaluateJavascript(js, null);
    }

    private PrintRequestData parseNativePrintRequest(String raw) {
        String input = raw == null ? "" : raw.trim();
        if (input.startsWith("{")) {
            try {
                JSONObject obj = new JSONObject(input);
                return new PrintRequestData(
                        obj.optString("action", "print"),
                        obj.optString("title", "E-SISWA"),
                        obj.optString("baseUrl", START_URL),
                        obj.optString("printHtml", "")
                );
            } catch (Exception ignored) {
                // Fall through for older pages that only sent a title.
            }
        }
        return new PrintRequestData("print", input.isEmpty() ? "E-SISWA" : input, START_URL, "");
    }

    private void startNativePrint(WebView source, String requestJson, JavaScriptReplyProxy replyProxy) {
        startNativePrint(source, parseNativePrintRequest(requestJson), replyProxy);
    }

    private void startNativePrint(WebView source, PrintRequestData request, JavaScriptReplyProxy replyProxy) {
        if (source == null || isFinishing()) {
            dispatchAfterPrint(source, replyProxy);
            return;
        }
        if (pendingPrintWebView != null) {
            boolean stale = isPendingPrintStateStale();
            boolean focusRecovered = hasWindowFocus() && source.hasWindowFocus();
            if (stale || focusRecovered) {
                clearPendingPrintState(true);
            }
        }
        if (pendingPrintWebView != null) {
            toast("Dialog cetak masih terbuka.");
            dispatchAfterPrint(source, replyProxy);
            return;
        }
        String title = sanitizePrintTitle(request == null ? "" : request.title);
        String jobName = "E-SISWA - " + title;
        try {
            PrintManager printManager = (PrintManager) getSystemService(Context.PRINT_SERVICE);
            if (printManager == null) {
                toast("Layanan cetak Android tidak tersedia.");
                dispatchAfterPrint(source, replyProxy);
                return;
            }
            PrintDocumentAdapter adapter = source.createPrintDocumentAdapter(jobName);
            pendingPrintWebView = source;
            pendingPrintReplyProxy = replyProxy;
            pendingPrintLostFocus = false;
            pendingPrintStartedAtMs = SystemClock.elapsedRealtime();
            printManager.print(jobName, adapter, new PrintAttributes.Builder().build());
        } catch (Exception livePrintError) {
            clearPendingPrintState(false);
            requestSnapshotFallback(source, request, replyProxy);
        }
    }

    private String sanitizePrintTitle(String requestedTitle) {
        String title = requestedTitle == null ? "" : requestedTitle.trim();
        if (title.isEmpty()) title = "E-SISWA";
        return title.length() > 80 ? title.substring(0, 80) : title;
    }

    private boolean isPendingPrintStateStale() {
        return pendingPrintWebView != null
                && pendingPrintStartedAtMs > 0
                && (SystemClock.elapsedRealtime() - pendingPrintStartedAtMs) > PRINT_STALE_TIMEOUT_MS;
    }

    private void clearPendingPrintState(boolean destroySnapshot) {
        WebView snapshot = pendingPrintSnapshotWebView;
        pendingPrintWebView = null;
        pendingPrintReplyProxy = null;
        pendingPrintLostFocus = false;
        pendingPrintSnapshotWebView = null;
        pendingPrintStartedAtMs = 0L;
        if (destroySnapshot) destroySnapshotPrintWebView(snapshot);
    }

    private void requestSnapshotFallback(WebView source, PrintRequestData request, JavaScriptReplyProxy replyProxy) {
        if (replyProxy != null) {
            try {
                replyProxy.postMessage("request-snapshot");
                return;
            } catch (Exception ignored) {
                // Fall through to legacy snapshot data if one was supplied.
            }
        }
        if (request != null && request.printHtml != null && !request.printHtml.trim().isEmpty()) {
            startSnapshotPrint(source, request, replyProxy);
            return;
        }
        toast("Mode cetak Android gagal dibuka.");
        dispatchAfterPrint(source, replyProxy);
    }

    private void startSnapshotPrint(WebView source, PrintRequestData request, JavaScriptReplyProxy replyProxy) {
        try {
            WebView snapshot = new WebView(this);
            WebSettings settings = snapshot.getSettings();
            settings.setJavaScriptEnabled(false);
            settings.setDomStorageEnabled(true);
            settings.setLoadsImagesAutomatically(true);
            settings.setUseWideViewPort(true);
            settings.setLoadWithOverviewMode(true);
            settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
            pendingPrintWebView = source;
            pendingPrintReplyProxy = replyProxy;
            pendingPrintLostFocus = false;
            pendingPrintStartedAtMs = SystemClock.elapsedRealtime();
            pendingPrintSnapshotWebView = snapshot;
            snapshot.setWebViewClient(new SnapshotPrintWebViewClient(source, snapshot, request, replyProxy));
            String baseUrl = request.baseUrl == null || request.baseUrl.trim().isEmpty() ? START_URL : request.baseUrl.trim();
            snapshot.loadDataWithBaseURL(baseUrl, request.printHtml, "text/html", "UTF-8", null);
        } catch (Exception snapshotError) {
            failSnapshotPrint(source, replyProxy);
        }
    }

    private final class SnapshotPrintWebViewClient extends WebViewClient {
        private final WebView source;
        private final WebView snapshot;
        private final PrintRequestData request;
        private final JavaScriptReplyProxy replyProxy;
        private boolean printStarted;

        SnapshotPrintWebViewClient(WebView source, WebView snapshot, PrintRequestData request, JavaScriptReplyProxy replyProxy) {
            this.source = source;
            this.snapshot = snapshot;
            this.request = request;
            this.replyProxy = replyProxy;
        }

        @Override
        public void onPageFinished(WebView view, String url) {
            if (printStarted || snapshot != pendingPrintSnapshotWebView) return;
            printStarted = true;
            snapshot.postDelayed(() -> {
                if (snapshot != pendingPrintSnapshotWebView || isFinishing()) return;
                try {
                    PrintManager printManager = (PrintManager) getSystemService(Context.PRINT_SERVICE);
                    if (printManager == null) throw new IllegalStateException("PrintManager unavailable");
                    String jobName = "E-SISWA - " + sanitizePrintTitle(request.title);
                    PrintDocumentAdapter adapter = snapshot.createPrintDocumentAdapter(jobName);
                    printManager.print(jobName, adapter, new PrintAttributes.Builder().build());
                } catch (Exception snapshotPrintError) {
                    failSnapshotPrint(source, replyProxy);
                }
            }, 550);
        }
    }

    private void failSnapshotPrint(WebView source, JavaScriptReplyProxy replyProxy) {
        WebView snapshot = pendingPrintSnapshotWebView;
        clearPendingPrintState(false);
        destroySnapshotPrintWebView(snapshot);
        toast("Mode cetak Android gagal dibuka.");
        dispatchAfterPrint(source, replyProxy);
    }

    private void destroySnapshotPrintWebView(WebView snapshot) {
        if (snapshot == null) return;
        try { snapshot.stopLoading(); } catch (Exception ignored) {}
        try { snapshot.setWebViewClient(null); } catch (Exception ignored) {}
        try { snapshot.destroy(); } catch (Exception ignored) {}
    }

    private void dispatchAfterPrint(WebView printedView, JavaScriptReplyProxy replyProxy) {
        if (replyProxy != null) {
            try {
                replyProxy.postMessage("afterprint");
                return;
            } catch (Exception ignored) {
                // Fallback ke main-frame event untuk WebView lama / frame yang sudah berpindah.
            }
        }
        if (printedView == null) return;
        printedView.evaluateJavascript("(function(){try{window.dispatchEvent(new Event('afterprint'));}catch(e){}})();", null);
    }

    private final class PrintBridge {
        private final WebView source;
        PrintBridge(WebView source) { this.source = source; }

        @JavascriptInterface
        public void printPage(String title, String baseUrl, String printHtml) {
            PrintRequestData request = new PrintRequestData("print", title, baseUrl, printHtml);
            runOnUiThread(() -> startNativePrint(source, request, null));
        }
    }

    private String nativeNotificationMirrorDocumentStartScript() {
        return "(function(){"
                + "if(window.__ESISWA_NATIVE_NOTIFY_MIRROR_INSTALLED)return;"
                + "if(!window.ESISWANotifyNative||typeof window.ESISWANotifyNative.postMessage!=='function')return;"
                + "window.__ESISWA_NATIVE_NOTIFY_MIRROR_INSTALLED=true;"
                + "var last=-1;"
                + "function readBadge(){"
                + "var b=document.getElementById('globalNotificationBadgeR535244');if(!b)return;"
                + "var raw=(b.textContent||'').trim();var n=parseInt(raw,10);if(!isFinite(n))n=0;"
                + "if((b.classList&&b.classList.contains('hidden'))||n<0)n=0;"
                + "if(n===last)return;last=n;"
                + "var payload={notifyCount:n,title:'Notifikasi E-SISWA',body:n>0?('Ada '+n+' notifikasi belum dibaca.'):'',kind:'general',view:'notification_center'};"
                + "try{window.ESISWANotifyNative.postMessage(JSON.stringify(payload));}catch(e){}"
                + "}"
                + "function boot(){if(!document.documentElement){setTimeout(boot,50);return;}"
                + "var o=new MutationObserver(readBadge);o.observe(document.documentElement,{subtree:true,childList:true,characterData:true,attributes:true,attributeFilter:['class']});"
                + "readBadge();setTimeout(readBadge,500);setTimeout(readBadge,1500);"
                + "}boot();"
                + "})();";
    }

    private void configureNativeNotificationMirror(WebView target) {
        if (target == null) return;
        try {
            if (!WebViewFeature.isFeatureSupported(WebViewFeature.WEB_MESSAGE_LISTENER)
                    || !WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) return;
            java.util.Set<String> origins = trustedPrintOrigins();
            WebViewCompat.addWebMessageListener(
                    target,
                    "ESISWANotifyNative",
                    origins,
                    (view, message, sourceOrigin, isMainFrame, replyProxy) -> {
                        if (message == null || message.getType() != WebMessageCompat.TYPE_STRING) return;
                        if (!isTrustedWebOrigin(sourceOrigin)) return;
                        final String raw = message.getData();
                        runOnUiThread(() -> handleMirroredWebNotification(raw));
                    }
            );
            WebViewCompat.addDocumentStartJavaScript(target, nativeNotificationMirrorDocumentStartScript(), origins);
        } catch (Exception ignored) {
            // FCM remains the background notification path when the mirror is unavailable.
        }
    }

    private void handleMirroredWebNotification(String raw) {
        try {
            JSONObject obj = new JSONObject(raw == null ? "{}" : raw);
            int count = Math.max(0, obj.optInt("notifyCount", 0));
            SharedPreferences prefs = getSharedPreferences(WEB_NOTIFICATION_PREFS, Context.MODE_PRIVATE);
            int previous = Math.max(0, prefs.getInt(KEY_LAST_WEB_BADGE_COUNT, 0));
            if (count == 0) {
                PushMessagingService.updateWebBadgeNotification(
                        this, "(SSD) SMPN4D", "", "pembinaan_new", "pembinaan", 0, false);
            } else if (count > previous) {
                showMirroredWebNotification(
                        obj.optString("title", "(SSD) SMPN4D"),
                        obj.optString("body", "Ada " + count + " notifikasi baru yang belum dibaca."),
                        obj.optString("kind", "pembinaan_new"),
                        obj.optString("view", "pembinaan"),
                        count,
                        true
                );
            } else if (count <= previous && count > 0) {
                showMirroredWebNotification(
                        obj.optString("title", "(SSD) SMPN4D"),
                        obj.optString("body", "Ada " + count + " notifikasi baru yang belum dibaca."),
                        obj.optString("kind", "pembinaan_new"),
                        obj.optString("view", "pembinaan"),
                        count,
                        false
                );
            }
            prefs.edit().putInt(KEY_LAST_WEB_BADGE_COUNT, count).apply();
        } catch (Exception ignored) {}
    }

    private void showMirroredWebNotification(String title, String body, String kind, String view,
                                             int count, boolean alert) {
        PushMessagingService.updateWebBadgeNotification(this, title, body, kind, view, count, alert);
    }

    private static final class PrintRequestData {
        final String action;
        final String title;
        final String baseUrl;
        final String printHtml;

        PrintRequestData(String action, String title, String baseUrl, String printHtml) {
            this.action = action == null ? "print" : action;
            this.title = title == null ? "" : title;
            this.baseUrl = baseUrl == null ? "" : baseUrl;
            this.printHtml = printHtml == null ? "" : printHtml;
        }

        boolean isSnapshot() {
            return "snapshot".equalsIgnoreCase(action);
        }
    }

    private class ESiswaWebViewClient extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
            Uri uri = request.getUrl();
            String scheme = uri.getScheme() == null ? "" : uri.getScheme().toLowerCase(Locale.ROOT);
            if ("file".equals(scheme) && uri.toString().startsWith("file:///android_asset/")) return false;
            if (("http".equals(scheme) || "https".equals(scheme)) && isTrustedWebOrigin(uri)) return false;
            return openExternal(uri);
        }

        @Override
        public void onPageStarted(WebView view, String url, Bitmap favicon) {
            if (view == webView) {
                progressBar.setVisibility(View.VISIBLE);
                progressBar.setProgress(5);
            }
        }

        @Override
        public void onPageCommitVisible(WebView view, String url) {
            scheduleAppsScriptOuterFrameNormalization(view, url);
            installNativePrintBridge(view);
            if (view != webView) {
                applyCameraPopupSafeArea(view, popupBottomInsets.getOrDefault(view, resolveNavigationBarHeight()));
            }
            if (view == webView) hideLaunchOverlay();
        }

        @Override
        public void onPageFinished(WebView view, String url) {
            scheduleAppsScriptOuterFrameNormalization(view, url);
            installNativePrintBridge(view);
            if (view != webView) {
                applyCameraPopupSafeArea(view, popupBottomInsets.getOrDefault(view, resolveNavigationBarHeight()));
            }
            if (view == webView) {
                progressBar.setProgress(100);
                progressBar.setVisibility(View.GONE);
            }
            CookieManager.getInstance().flush();
            if (view == webView) {
                enforceLoginSystemFirst(view);
                deliverCachedFcmTokenToPage();
                deliverPendingPushOpenToPage();
            }
        }

        @Override
        public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
            if (request.isForMainFrame()) {
                Uri uri = request.getUrl();
                if (uri != null && ("http".equalsIgnoreCase(uri.getScheme()) || "https".equalsIgnoreCase(uri.getScheme()))) {
                    showOffline(view);
                }
            }
        }
    }

    // vRC.2: override the web runtime's delayed Album Alumni default at startup.
    private void enforceLoginSystemFirst(WebView target) {
        if (target == null) return;
        String js = "(function(){try{if(window.__esiswaLoginFirstDone||window.__esiswaLoginFirstTimer)return;"
                + "var n=0;function f(){n++;try{if(typeof window.switchLandingTabR5345==='function'&&document.getElementById('loginSystemPanelR5345')){"
                + "window.switchLandingTabR5345('login');var p=document.getElementById('loginSystemPanelR5345');var a=document.getElementById('albumAlumniPanelR5345');"
                + "if(p&&!p.classList.contains('hidden')&&(!a||a.classList.contains('hidden'))){window.__esiswaLoginFirstDone=true;clearInterval(window.__esiswaLoginFirstTimer);window.__esiswaLoginFirstTimer=null;return;}}}catch(e){}"
                + "if(n>=40){clearInterval(window.__esiswaLoginFirstTimer);window.__esiswaLoginFirstTimer=null;}}window.__esiswaLoginFirstTimer=setInterval(f,100);f();}catch(e){}})();";
        target.evaluateJavascript(js, null);
    }

    private class ESiswaChromeClient extends WebChromeClient {
        private final WebView owner;
        ESiswaChromeClient(WebView owner) { this.owner = owner; }

        @Override
        public void onProgressChanged(WebView view, int newProgress) {
            if (view == webView) {
                progressBar.setProgress(newProgress);
                progressBar.setVisibility(newProgress >= 100 ? View.GONE : View.VISIBLE);
            }
        }

        @Override
        public void onPermissionRequest(PermissionRequest request) {
            runOnUiThread(() -> {
                if (!isTrustedCameraOrigin(request.getOrigin())) {
                    request.deny();
                    return;
                }
                boolean asksVideo = Arrays.asList(request.getResources()).contains(PermissionRequest.RESOURCE_VIDEO_CAPTURE);
                if (!asksVideo) {
                    request.deny();
                    return;
                }
                if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                    request.grant(new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE});
                } else {
                    if (pendingWebPermission != null) pendingWebPermission.deny();
                    pendingWebPermission = request;
                    requestPermissions(new String[]{Manifest.permission.CAMERA}, REQ_CAMERA);
                }
            });
        }

        @Override
        public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> callback,
                                         FileChooserParams fileChooserParams) {
            if (filePathCallback != null) filePathCallback.onReceiveValue(null);
            filePathCallback = callback;
            Intent intent;
            try {
                intent = fileChooserParams.createIntent();
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                startActivityForResult(intent, REQ_FILE_CHOOSER);
            } catch (ActivityNotFoundException ex) {
                intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                try {
                    startActivityForResult(intent, REQ_FILE_CHOOSER);
                } catch (ActivityNotFoundException noPicker) {
                    filePathCallback.onReceiveValue(null);
                    filePathCallback = null;
                    Toast.makeText(MainActivity.this, "Pemilih file tidak tersedia.", Toast.LENGTH_SHORT).show();
                }
            }
            return true;
        }

        @Override
        public boolean onCreateWindow(WebView view, boolean isDialog, boolean isUserGesture, Message resultMsg) {
            if (!isUserGesture) return false;
            Dialog dialog = new Dialog(MainActivity.this, android.R.style.Theme_DeviceDefault_Light_NoActionBar);
            WebView popup = new WebView(MainActivity.this);
            configureWebView(popup, true);
            dialog.setContentView(popup, new ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            dialog.setOnDismissListener(d -> {
                popupDialogs.remove(popup);
                popupBottomInsets.remove(popup);
                modernPrintBridge.remove(popup);
                popup.stopLoading();
                popup.removeJavascriptInterface("ESISWAPrint");
                popup.destroy();
            });
            dialog.show();
            Window window = dialog.getWindow();
            if (window != null) {
                window.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
                applyPopupSystemInsets(popup, window);
            }
            popupDialogs.put(popup, dialog);
            WebView.WebViewTransport transport = (WebView.WebViewTransport) resultMsg.obj;
            transport.setWebView(popup);
            resultMsg.sendToTarget();
            return true;
        }

        @Override
        public void onCloseWindow(WebView window) {
            Dialog dialog = popupDialogs.remove(window);
            if (dialog != null) dialog.dismiss();
            else window.destroy();
        }
    }

    private class ESiswaDownloadListener implements DownloadListener {
        private final WebView source;
        ESiswaDownloadListener(WebView source) { this.source = source; }

        @Override
        public void onDownloadStart(String url, String userAgent, String contentDisposition,
                                    String mimetype, long contentLength) {
            if (url == null) return;
            if (url.startsWith("blob:") || url.startsWith("data:")) {
                handleBlobDownload(source, url, contentDisposition, mimetype);
                return;
            }
            Uri uri = Uri.parse(url);
            if (!"https".equalsIgnoreCase(uri.getScheme()) && !"http".equalsIgnoreCase(uri.getScheme())) {
                Toast.makeText(MainActivity.this, "Jenis unduhan tidak didukung.", Toast.LENGTH_SHORT).show();
                return;
            }
            PendingDownload data = new PendingDownload(url, userAgent, contentDisposition, mimetype);
            if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P
                    && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                pendingDownload = data;
                requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQ_WRITE_STORAGE);
            } else {
                enqueueDownload(data);
            }
        }
    }

    private void enqueueDownload(PendingDownload data) {
        try {
            String filename = safeFilename(URLUtil.guessFileName(data.url, data.contentDisposition, data.mime));
            DownloadManager.Request req = new DownloadManager.Request(Uri.parse(data.url));
            req.setTitle(filename);
            req.setDescription("Unduhan E-SISWA");
            req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            req.setAllowedOverMetered(true);
            req.setAllowedOverRoaming(true);
            if (data.mime != null && !data.mime.isEmpty()) req.setMimeType(data.mime);
            if (data.userAgent != null) req.addRequestHeader("User-Agent", data.userAgent);
            String cookie = CookieManager.getInstance().getCookie(data.url);
            if (cookie != null) req.addRequestHeader("Cookie", cookie);
            req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "E-SISWA/" + filename);
            DownloadManager dm = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
            dm.enqueue(req);
            Toast.makeText(this, "Mengunduh " + filename, Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Unduhan gagal dimulai.", Toast.LENGTH_LONG).show();
        }
    }

    private void handleBlobDownload(WebView source, String url, String contentDisposition, String mimetype) {
        String filename = safeFilename(URLUtil.guessFileName("download", contentDisposition, mimetype));
        String js = "(function(){" +
                "const u=" + JSONObject.quote(url) + ";" +
                "fetch(u).then(r=>r.blob()).then(b=>{" +
                "if(b.size>" + MAX_BLOB_BYTES + "){throw new Error('too-large');}" +
                "const fr=new FileReader();fr.onloadend=function(){" +
                "ESISWANative.saveBase64Download(fr.result," + JSONObject.quote(filename) + ",b.type||" + JSONObject.quote(mimetype == null ? "application/octet-stream" : mimetype) + ");};" +
                "fr.readAsDataURL(b);" +
                "}).catch(()=>ESISWANative.downloadFailed());" +
                "})();";
        source.evaluateJavascript(js, null);
    }

    public static class DownloadBridge {
        private final MainActivity activity;
        DownloadBridge(MainActivity activity) { this.activity = activity; }

        @JavascriptInterface
        public void saveBase64Download(String dataUrl, String filename, String mime) {
            if (dataUrl == null) return;
            int comma = dataUrl.indexOf(',');
            if (comma < 0) return;
            try {
                String encoded = dataUrl.substring(comma + 1);
                byte[] bytes = android.util.Base64.decode(encoded, android.util.Base64.DEFAULT);
                if (bytes.length > MAX_BLOB_BYTES) {
                    activity.toast("File terlalu besar untuk disimpan dari WebView.");
                    return;
                }
                activity.saveDownloadedBytes(bytes, filename, mime);
            } catch (Exception e) {
                activity.toast("Unduhan gagal disimpan.");
            }
        }

        @JavascriptInterface
        public void downloadFailed() {
            activity.toast("Unduhan dari halaman gagal diproses.");
        }
    }

    private void saveDownloadedBytes(byte[] bytes, String requestedName, String mime) throws Exception {
        String filename = safeFilename(requestedName);
        String safeMime = (mime == null || mime.trim().isEmpty()) ? inferMime(filename) : mime.split(";")[0];
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ContentValues values = new ContentValues();
            values.put(MediaStore.Downloads.DISPLAY_NAME, filename);
            values.put(MediaStore.Downloads.MIME_TYPE, safeMime);
            values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/E-SISWA");
            values.put(MediaStore.Downloads.IS_PENDING, 1);
            Uri item = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
            if (item == null) throw new IllegalStateException("Cannot create download");
            try (OutputStream out = getContentResolver().openOutputStream(item)) {
                if (out == null) throw new IllegalStateException("Cannot open download");
                out.write(bytes);
            }
            values.clear();
            values.put(MediaStore.Downloads.IS_PENDING, 0);
            getContentResolver().update(item, values, null, null);
        } else {
            if (checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                throw new SecurityException("Storage permission not granted");
            }
            File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "E-SISWA");
            if (!dir.exists() && !dir.mkdirs()) throw new IllegalStateException("Cannot create Downloads/E-SISWA");
            try (FileOutputStream out = new FileOutputStream(new File(dir, filename))) {
                out.write(bytes);
            }
        }
        toast("Tersimpan: " + filename);
    }

    private static String safeFilename(String name) {
        if (name == null || name.trim().isEmpty()) name = "E-SISWA-download";
        name = name.replaceAll("[\\\\/:*?\"<>|\\p{Cntrl}]", "_").trim();
        if (name.length() > 120) name = name.substring(0, 120);
        return name.isEmpty() ? "E-SISWA-download" : name;
    }

    private static String inferMime(String filename) {
        int dot = filename.lastIndexOf('.');
        if (dot > 0 && dot < filename.length() - 1) {
            String m = MimeTypeMap.getSingleton().getMimeTypeFromExtension(filename.substring(dot + 1).toLowerCase(Locale.ROOT));
            if (m != null) return m;
        }
        return "application/octet-stream";
    }

    private void toast(String text) {
        runOnUiThread(() -> Toast.makeText(this, text, Toast.LENGTH_SHORT).show());
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_FILE_CHOOSER || filePathCallback == null) return;
        Uri[] results = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
        filePathCallback.onReceiveValue(results);
        filePathCallback = null;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_CAMERA) {
            PermissionRequest req = pendingWebPermission;
            pendingWebPermission = null;
            if (req != null) {
                boolean granted = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
                if (granted && isTrustedCameraOrigin(req.getOrigin())) {
                    req.grant(new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE});
                } else {
                    req.deny();
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
                            && !shouldShowRequestPermissionRationale(Manifest.permission.CAMERA)) {
                        showPermissionSettingsDialog(
                                "Izin Kamera Diperlukan",
                                "Aktifkan izin Kamera untuk E-SISWA agar Scan QR, Face Recognition, foto profil guru, dan foto siswa dapat digunakan."
                        );
                    } else {
                        toast("Izin kamera diperlukan. Tekan Coba Lagi lalu pilih Izinkan.");
                    }
                }
            }
        } else if (requestCode == REQ_NOTIFICATIONS) {
            if (grantResults.length == 0 || grantResults[0] != PackageManager.PERMISSION_GRANTED) {
                if (Build.VERSION.SDK_INT >= 33
                        && !shouldShowRequestPermissionRationale(Manifest.permission.POST_NOTIFICATIONS)) {
                    showPermissionSettingsDialog(
                            "Izin Notifikasi Diperlukan",
                            "Aktifkan notifikasi E-SISWA agar pemberitahuan Pembinaan dan Absensi Masuk/Pulang dapat diterima di perangkat ini."
                    );
                } else {
                    toast("Notifikasi belum diizinkan. Izin dapat diberikan saat diminta kembali.");
                }
            } else {
                refreshFcmToken();
            }
        } else if (requestCode == REQ_WRITE_STORAGE) {
            PendingDownload download = pendingDownload;
            pendingDownload = null;
            if (download != null && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                enqueueDownload(download);
            } else if (download != null) {
                toast("Izin penyimpanan diperlukan untuk unduhan pada Android lama.");
            }
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (pendingPrintWebView == null) return;
        if (!hasFocus) {
            pendingPrintLostFocus = true;
            return;
        }
        if (pendingPrintLostFocus) {
            WebView printedView = pendingPrintWebView;
            JavaScriptReplyProxy replyProxy = pendingPrintReplyProxy;
            WebView snapshot = pendingPrintSnapshotWebView;
            clearPendingPrintState(false);
            destroySnapshotPrintWebView(snapshot);
            if (printedView != null) printedView.postDelayed(() -> dispatchAfterPrint(printedView, replyProxy), 300);
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        webView.saveState(outState);
        super.onSaveInstanceState(outState);
    }

    @Override
    protected void onPause() {
        CookieManager.getInstance().flush();
        webView.onPause();
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        webView.onResume();
        refreshFcmToken();
        deliverPendingPushOpenToPage();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        capturePushIntent(intent);
        deliverPendingPushOpenToPage();
    }

    @Override
    public void onBackPressed() {
        if (!popupDialogs.isEmpty()) {
            List<Dialog> dialogs = new ArrayList<>(popupDialogs.values());
            dialogs.get(dialogs.size() - 1).dismiss();
            return;
        }
        if (webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        if (filePathCallback != null) filePathCallback.onReceiveValue(null);
        if (pendingWebPermission != null) pendingWebPermission.deny();
        for (Dialog d : new ArrayList<>(popupDialogs.values())) d.dismiss();
        popupDialogs.clear();
        popupBottomInsets.clear();
        modernPrintBridge.clear();
        destroySnapshotPrintWebView(pendingPrintSnapshotWebView);
        clearPendingPrintState(false);
        webView.stopLoading();
        webView.removeJavascriptInterface("ESISWANative");
        webView.removeJavascriptInterface("ESISWAPrint");
        webView.removeJavascriptInterface("ESISWAAndroidPush");
        webView.destroy();
        super.onDestroy();
    }

    private static final class PendingDownload {
        final String url;
        final String userAgent;
        final String contentDisposition;
        final String mime;
        PendingDownload(String url, String userAgent, String contentDisposition, String mime) {
            this.url = url;
            this.userAgent = userAgent;
            this.contentDisposition = contentDisposition;
            this.mime = mime;
        }
    }
}
