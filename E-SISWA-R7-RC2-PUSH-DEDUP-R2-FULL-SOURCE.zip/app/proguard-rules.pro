# E-SISWA WebView wrapper uses no reflection-based third-party libraries.
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
