from pathlib import Path
import hashlib, sys
root=Path(__file__).resolve().parents[1]
main=(root/'app/src/main/java/id/sch/smpn4dumai/esiswa/MainActivity.java').read_text(encoding='utf-8')
push=(root/'app/src/main/java/id/sch/smpn4dumai/esiswa/PushMessagingService.java').read_text(encoding='utf-8')
gradle=(root/'app/build.gradle').read_text(encoding='utf-8')
checks={
 'version 1.1.3.5.2 code 12': "versionName '1.1.3.5.2'" in gradle and 'versionCode 12' in gradle,
 'v4 print bridge installed': '__ESISWA_NATIVE_PRINT_V4_INSTALLED' in main,
 'initial print request is lightweight': "function lightRequest(){return JSON.stringify({action:'print'" in main and "postMessage(lightRequest())" in main,
 'initial request omits printHtml': "function lightRequest(){return JSON.stringify({action:'print',title:" in main,
 'snapshot html generated only in snapshotRequest': 'function snapshotRequest()' in main and "action:'snapshot'" in main and 'cloneNode(true)' in main,
 'native requests snapshot only on live failure': 'requestSnapshotFallback' in main and 'replyProxy.postMessage("request-snapshot")' in main,
 'snapshot response routed directly to snapshot printer': 'request.isSnapshot()' in main and 'startSnapshotPrint(view, request, replyProxy)' in main,
 'live WebView PrintManager stays primary': 'source.createPrintDocumentAdapter(jobName)' in main and 'printManager.print(jobName, adapter' in main,
 'legacy print bridge retained': 'window.ESISWAPrint.printPage' in main and '@JavascriptInterface' in main,
 'print state recovery retained': 'PRINT_STALE_TIMEOUT_MS = 8000L' in main and 'clearPendingPrintState' in main,
 'FCM token bridge retained': 'ESISWAAndroidPush' in main and 'FirebaseMessaging' in main,
 'push diagnostics retained': 'getNativePushStatus' in main and 'requestFcmTokenRefresh' in main,
 'native notification mirror retained': 'ESISWANotifyNative' in main and 'configureNativeNotificationMirror' in main,
 'notification permission retained': 'Manifest.permission.POST_NOTIFICATIONS' in main,
 'push service local notification retained': 'public static void showLocalNotification' in push,
 'camera safe-area retained': 'applyCameraPopupSafeArea' in main and '--esiswa-native-nav-bottom' in main,
}
bad=[]
for n,ok in checks.items():
    print(('PASS' if ok else 'FAIL')+' | '+n)
    if not ok: bad.append(n)
print(f'SUMMARY: {len(checks)-len(bad)}/{len(checks)} PASS; failures={len(bad)}')
sys.exit(1 if bad else 0)
