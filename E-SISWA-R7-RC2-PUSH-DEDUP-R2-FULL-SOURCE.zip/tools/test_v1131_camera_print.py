from pathlib import Path
import sys

root = Path(__file__).resolve().parents[1]
main = (root / 'app/src/main/java/id/sch/smpn4dumai/esiswa/MainActivity.java').read_text()
build = (root / 'app/build.gradle').read_text()

checks = {
    'Camera patch lineage preserved': (("versionName '1.1.3.1'" in build and 'versionCode 6' in build) or ("versionName '1.1.3.2'" in build and 'versionCode 7' in build) or ("versionName '1.1.3.3'" in build and 'versionCode 8' in build) or ("versionName '1.1.3.4'" in build and 'versionCode 9' in build) or ("versionName '1.1.3.5'" in build and 'versionCode 10' in build) or ("versionName '1.1.3.5.1'" in build and 'versionCode 11' in build) or ("versionName '1.1.3.5.2'" in build and 'versionCode 12' in build)),
    'Android native print imports': 'android.print.PrintManager' in main and 'android.print.PrintDocumentAdapter' in main,
    'Native print JavaScript bridge': '"ESISWAPrint"' in main and '@JavascriptInterface' in main and 'printPage' in main,
    'Print adapter invocation': 'createPrintDocumentAdapter' in main and 'printManager.print' in main,
    'window.print override injection': ('__ESISWA_NATIVE_PRINT_V4_INSTALLED' in main or '__ESISWA_NATIVE_PRINT_V3_INSTALLED' in main or '__ESISWA_NATIVE_PRINT_INSTALLED' in main) and 'window.print=function' in main.replace(' ', ''),
    'afterprint cleanup after native dialog': "dispatchEvent(new Event('afterprint'))" in main or 'dispatchAfterPrint' in main,
    'Camera popup CSS safe-area injection': 'esiswa-native-camera-safe-area' in main,
    'Camera buttons protected from navigation': '--esiswa-native-nav-bottom' in main and '#btns' in main and 'margin-bottom' in main,
    'Camera portrait preview height capped': '100dvh' in main and '#videoWrap' in main and 'max-height' in main,
    'Navigation bar fallback when inset is zero': 'navigation_bar_height' in main,
    'v1.1.3 responsive behavior preserved': 'MOBILE_PAGE_SCALE = 0.88' in main and 'setTextZoom(96)' in main and 'enforceResponsiveViewport(view)' in main,
    'v1.1.2 permission behavior preserved': 'PermissionRequest.RESOURCE_VIDEO_CAPTURE' in main and 'Manifest.permission.CAMERA' in main,
}

for name, ok in checks.items():
    print(('PASS' if ok else 'FAIL') + ' - ' + name)

failed = [name for name, ok in checks.items() if not ok]
if failed:
    print(f'FAIL {len(failed)}/{len(checks)} checks failed')
    sys.exit(1)
print(f'PASS {len(checks)}/{len(checks)} checks')
