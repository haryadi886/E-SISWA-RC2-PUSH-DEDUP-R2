from pathlib import Path
root=Path(__file__).resolve().parents[1]
strings=(root/'app/src/main/res/values/strings.xml').read_text()
build=(root/'app/build.gradle').read_text()
layout=(root/'app/src/main/res/layout/activity_main.xml').read_text()
icon=root/'app/src/main/res/drawable-nodpi/esiswa_logo.webp'
checks={
 'app name (SSD) SMPN4D':'<string name="app_name">(SSD) SMPN4D</string>' in strings,
 'version 1.1.3.5.1+ branding lineage':(("versionName '1.1.3.5.1'" in build and 'versionCode 11' in build) or ("versionName '1.1.3.5.2'" in build and 'versionCode 12' in build)),
 'new launcher logo nonempty':icon.exists() and icon.stat().st_size>10000,
 'launch overlay uses new logo':'android:src="@drawable/esiswa_logo"' in layout,
}
bad=[k for k,v in checks.items() if not v]
for k,v in checks.items(): print(('PASS' if v else 'FAIL')+' - '+k)
if bad: raise SystemExit('Branding regression failed: '+', '.join(bad))
print('PASS 4/4 branding checks')
