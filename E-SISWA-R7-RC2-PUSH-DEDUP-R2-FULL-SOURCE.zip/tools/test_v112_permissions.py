from pathlib import Path
import sys
r=Path(__file__).resolve().parents[1]
m=(r/'app/src/main/java/id/sch/smpn4dumai/esiswa/MainActivity.java').read_text()
mf=(r/'app/src/main/AndroidManifest.xml').read_text()
b=(r/'app/build.gradle').read_text()
c={
"Version lineage 1.1.3":(("versionName '1.1.3'" in b and 'versionCode 5' in b) or ("versionName '1.1.3.1'" in b and 'versionCode 6' in b) or ("versionName '1.1.3.2'" in b and 'versionCode 7' in b) or ("versionName '1.1.3.3'" in b and 'versionCode 8' in b) or ("versionName '1.1.3.4'" in b and 'versionCode 9' in b) or ("versionName '1.1.3.5'" in b and 'versionCode 10' in b) or ("versionName '1.1.3.5.1'" in b and 'versionCode 11' in b) or ("versionName '1.1.3.5.2'" in b and 'versionCode 12' in b)),
"Camera manifest permission":'android.permission.CAMERA' in mf,
"Notification manifest permission":'android.permission.POST_NOTIFICATIONS' in mf,
"Apps Script sandbox origin":'host.endsWith("-script.googleusercontent.com")' in m,
"Notification runtime request":'requestNotificationPermissionIfNeeded();' in m,
"Camera runtime request":'requestPermissions(new String[]{Manifest.permission.CAMERA}, REQ_CAMERA)' in m,
"Settings recovery":'showPermissionSettingsDialog' in m and 'Settings.ACTION_APPLICATION_DETAILS_SETTINGS' in m,
"Camera rationale":'shouldShowRequestPermissionRationale(Manifest.permission.CAMERA)' in m,
"Notification rationale":'shouldShowRequestPermissionRationale(Manifest.permission.POST_NOTIFICATIONS)' in m,
"Video-only WebView grant":'request.grant(new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE})' in m,
"No microphone grant":'RESOURCE_AUDIO_CAPTURE' not in m,
}
for k,v in c.items(): print(('PASS' if v else 'FAIL')+' - '+k)
f=[k for k,v in c.items() if not v]
print(f'PASS {len(c)-len(f)}/{len(c)} checks')
sys.exit(1 if f else 0)
