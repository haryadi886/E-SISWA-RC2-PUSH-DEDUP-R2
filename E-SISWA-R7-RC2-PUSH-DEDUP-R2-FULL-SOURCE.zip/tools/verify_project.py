from pathlib import Path
import re, sys
root=Path(__file__).resolve().parents[1]
errors=[]
def need(path, text=None, label=None):
    p=root/path
    if not p.exists(): errors.append(f'MISSING {path}'); return ''
    s=p.read_text(errors='ignore') if p.suffix.lower() not in {'.png','.webp','.jpg','.jpeg'} else ''
    if text is not None and text not in s: errors.append(f'MISSING {label or text} in {path}')
    return s
need(Path('settings.gradle'), 'rootProject.name = "E-SISWA-SSD"')
appgrad=need(Path('app/build.gradle'), "versionName '1.1.3.5.2'")
need(Path('app/build.gradle'), 'firebase-messaging', 'Firebase Messaging')
need(Path('app/build.gradle'), 'compileSdk 36')
manifest=need(Path('app/src/main/AndroidManifest.xml'), 'android.permission.POST_NOTIFICATIONS')
for needle in ['android.permission.INTERNET','android.permission.CAMERA','android.permission.ACCESS_NETWORK_STATE','.PushMessagingService','.ESiswaApplication']:
    if needle not in manifest: errors.append(f'MISSING manifest {needle}')
main=need(Path('app/src/main/java/id/sch/smpn4dumai/esiswa/MainActivity.java'))
service=need(Path('app/src/main/java/id/sch/smpn4dumai/esiswa/PushMessagingService.java'),'extends FirebaseMessagingService')
bootstrap=need(Path('app/src/main/java/id/sch/smpn4dumai/esiswa/FirebaseBootstrap.java'),'FirebaseOptions.Builder')
need(Path('app/src/main/java/id/sch/smpn4dumai/esiswa/ESiswaApplication.java'),'FirebaseBootstrap.ensureInitialized')
url='https://script.google.com/a/macros/admin.smp.belajar.id/s/AKfycbw-5rjaYuUG03_gB5TiBXUNG21-N2up1ikFBF9vM5F8m5srp6Mm2bmgMxZwwi-RoKE7GA/exec'
if url not in main: errors.append('Production START_URL mismatch/missing')
for needle,label in [
 ('setJavaScriptEnabled(true)','WebView JS'),('setAcceptThirdPartyCookies','cookies'),
 ('onPermissionRequest(PermissionRequest request)','camera callback'),('onShowFileChooser','file chooser'),
 ('setDownloadListener','download'),('handleBlobDownload','blob download'),('onCreateWindow','popup'),
 ('ESISWAAndroidPush','native push bridge'),('configureFirebase','runtime Firebase config'),
 ('esiswa-fcm-token','FCM token event'),('esiswa-native-push-open','push open event')]:
    if needle not in main: errors.append(f'MISSING behavior {label}')

for needle,label in [('setLoadWithOverviewMode(true)','responsive overview'),('setInitialScale(0)','auto initial scale'),('setTextZoom(96)','text zoom 96'),('onPageCommitVisible','fast launch commit'),('hideLaunchOverlay','launch overlay hide')]:
    if needle not in main: errors.append(f'MISSING behavior {label}')
need(Path('app/src/main/res/layout/activity_main.xml'), 'launchOverlay', 'fast launch overlay')
if not (root/'app/src/main/res/drawable-nodpi/launch_screen.jpg').exists(): errors.append('MISSING launch_screen.jpg')


for needle,label in [('MOBILE_PAGE_SCALE = 0.88','mobile scale'),('setOnApplyWindowInsetsListener','popup system inset'),('WindowInsets.Type.navigationBars()','navigation bar inset')]:
    if needle not in main: errors.append(f'MISSING behavior {label}')

for needle,label in [('CHANNEL_ATTENDANCE','attendance channel'),('CHANNEL_COACHING','coaching channel'),('POST_NOTIFICATIONS','notification permission'),('PendingIntent.FLAG_IMMUTABLE','immutable pending intent')]:
    if needle not in service: errors.append(f'MISSING {label}')
for needle,label in [('setProjectId','project id'),('setApplicationId','app id'),('setApiKey','api key'),('setGcmSenderId','sender id')]:
    if needle not in bootstrap: errors.append(f'MISSING Firebase option {label}')
for icon in ['app/src/main/res/mipmap-anydpi-v26/ic_launcher.xml','app/src/main/res/mipmap-anydpi-v26/ic_launcher_round.xml','app/src/main/res/drawable-nodpi/esiswa_logo.webp']:
    if not (root/icon).exists(): errors.append(f'MISSING {icon}')
# No secret/private key in Android source.
for p in root.rglob('*'):
    if not p.is_file() or p.name == 'verify_project.py' or any(part in {'.git','build','.gradle'} for part in p.parts): continue
    if p.suffix.lower() in {'.png','.jpg','.jpeg','.webp','.jar','.zip','.apk','.jks','.keystore'}: continue
    txt=p.read_text(errors='ignore')
    if '-----BEGIN PRIVATE KEY-----' in txt: errors.append(f'PRIVATE KEY in {p.relative_to(root)}')
    if re.search(r'AIza[0-9A-Za-z_-]{25,}',txt) and 'FIREBASE-PUSH-SETUP' not in p.name: errors.append(f'API KEY like value in {p.relative_to(root)}')
if errors:
    print('VERIFY FAIL:',len(errors))
    for e in errors: print(' -',e)
    sys.exit(1)
print('VERIFY PASS: (SSD) SMPN4D Android v1.1.3.5.2 project contract satisfied')
