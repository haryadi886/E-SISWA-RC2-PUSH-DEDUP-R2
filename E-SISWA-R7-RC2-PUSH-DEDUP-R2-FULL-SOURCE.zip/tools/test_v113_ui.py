from pathlib import Path
import hashlib, sys
root=Path(__file__).resolve().parents[1]
main=(root/'app/src/main/java/id/sch/smpn4dumai/esiswa/MainActivity.java').read_text()
build=(root/'app/build.gradle').read_text()
fg=(root/'app/src/main/res/drawable/ic_launcher_foreground.xml').read_text()
icon=root/'app/src/main/res/drawable-nodpi/esiswa_logo.webp'
checks={
    'Version lineage 1.1.3': ("versionName '1.1.3'" in build and 'versionCode 5' in build) or ("versionName '1.1.3.1'" in build and 'versionCode 6' in build) or ("versionName '1.1.3.2'" in build and 'versionCode 7' in build) or ("versionName '1.1.3.3'" in build and 'versionCode 8' in build) or ("versionName '1.1.3.4'" in build and 'versionCode 9' in build) or ("versionName '1.1.3.5'" in build and 'versionCode 10' in build) or ("versionName '1.1.3.5.1'" in build and 'versionCode 11' in build) or ("versionName '1.1.3.5.2'" in build and 'versionCode 12' in build),
    'Mobile page scale constant': 'MOBILE_PAGE_SCALE = 0.88' in main,
    'Responsive viewport scale injection': 'initial-scale=" + scale' in main and 'overflowX' in main,
    'Viewport applied to popup too': 'if (view != webView) return;' not in main[main.find('private void enforceResponsiveViewport'):main.find('private class ESiswaWebViewClient')],
    'Popup navigation inset listener': 'setOnApplyWindowInsetsListener' in main and 'WindowInsets.Type.navigationBars()' in main,
    'Popup bottom safe area': ('popup.setPadding' in main) or ('esiswa-native-camera-safe-area' in main and '--esiswa-native-nav-bottom' in main),
    'Launcher has safe inset': 'android:insetLeft="18dp"' in fg and 'android:insetTop="18dp"' in fg,
    'No Google banner DOM hack': 'Laporkan penyalahgunaan' not in main and 'Pelajari lebih lanjut' not in main,
}
for k,v in checks.items(): print(('PASS' if v else 'FAIL')+' - '+k)
failed=[k for k,v in checks.items() if not v]
if failed: sys.exit(1)
print(f'PASS {len(checks)}/{len(checks)} checks')
