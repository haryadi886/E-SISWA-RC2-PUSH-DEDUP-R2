from pathlib import Path
import sys,re
root=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parents[1]
main=(root/'app/src/main/java/id/sch/smpn4dumai/esiswa/MainActivity.java').read_text(encoding='utf-8')
build=(root/'app/build.gradle').read_text(encoding='utf-8')
checks={
 'version 1.1.3.5+ lineage': (("versionName '1.1.3.5'" in build and 'versionCode 10' in build) or ("versionName '1.1.3.5.1'" in build and 'versionCode 11' in build) or ("versionName '1.1.3.5.2'" in build and 'versionCode 12' in build)),
 'stale print timeout defined': 'PRINT_STALE_TIMEOUT_MS = 8000L' in main,
 'pending print start timestamp tracked': 'pendingPrintStartedAtMs' in main and 'SystemClock.elapsedRealtime()' in main,
 'stale state detector exists': 'isPendingPrintStateStale()' in main,
 'central print-state cleanup exists': 'clearPendingPrintState(boolean destroySnapshot)' in main,
 'new print clears recovered/stale lock': 'stale || focusRecovered' in main and 'clearPendingPrintState(true)' in main,
 'window focus cleanup retained': 'onWindowFocusChanged' in main and 'clearPendingPrintState(false)' in main,
 'native print primary retained': 'source.createPrintDocumentAdapter' in main and 'printManager.print' in main,
 'snapshot fallback retained': 'startSnapshotPrint' in main and 'loadDataWithBaseURL' in main,
 'camera safe-area retained': 'applyCameraPopupSafeArea' in main and '--esiswa-native-nav-bottom' in main,
 'FCM diagnostics retained': 'getNativePushStatus' in main and 'requestFcmTokenRefresh' in main,
}
for n,ok in checks.items(): print(('PASS' if ok else 'FAIL')+' | '+n)
bad=[n for n,ok in checks.items() if not ok]
print(f'SUMMARY: {len(checks)-len(bad)}/{len(checks)} PASS; failures={len(bad)}')
sys.exit(1 if bad else 0)
