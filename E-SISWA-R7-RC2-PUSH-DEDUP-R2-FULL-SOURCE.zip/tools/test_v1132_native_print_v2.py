from pathlib import Path
import sys

root = Path(__file__).resolve().parents[1]
main = (root / 'app/src/main/java/id/sch/smpn4dumai/esiswa/MainActivity.java').read_text(encoding='utf-8')
build = (root / 'app/build.gradle').read_text(encoding='utf-8')
manifest = (root / 'app/src/main/AndroidManifest.xml').read_text(encoding='utf-8')

checks = {
    'Version lineage through 1.1.3.3': (("versionName '1.1.3.2'" in build and 'versionCode 7' in build) or ("versionName '1.1.3.3'" in build and 'versionCode 8' in build) or ("versionName '1.1.3.4'" in build and 'versionCode 9' in build) or ("versionName '1.1.3.5'" in build and 'versionCode 10' in build) or ("versionName '1.1.3.5.1'" in build and 'versionCode 11' in build) or ("versionName '1.1.3.5.2'" in build and 'versionCode 12' in build)),
    'Jetpack WebKit dependency present': "androidx.webkit:webkit:1.17.0" in build,
    'Document-start injection APIs imported': 'androidx.webkit.WebViewCompat' in main and 'androidx.webkit.WebViewFeature' in main,
    'Bidirectional reply proxy imported': 'androidx.webkit.JavaScriptReplyProxy' in main and 'androidx.webkit.WebMessageCompat' in main,
    'Print bridge restricted to Apps Script origins': all(rule in main for rule in [
        'https://script.google.com',
        'https://script.googleusercontent.com',
        'https://*.script.googleusercontent.com',
        'https://*.googleusercontent.com',
    ]),
    'Web message listener registered for print': 'WebViewCompat.addWebMessageListener' in main and 'ESISWAPrintNative' in main,
    'Document-start script reaches iframe print calls': 'WebViewCompat.addDocumentStartJavaScript' in main and 'window.print=function' in main.replace(' ', ''),
    'Document-start script posts native print request': 'ESISWAPrintNative.postMessage' in main,
    'Calling frame receives native print completion': 'ESISWAPrintNative.onmessage' in main and "dispatchEvent(new Event('afterprint'))" in main,
    'Native callback keeps calling-frame reply proxy': 'JavaScriptReplyProxy' in main and 'replyProxy.postMessage' in main,
    'Android PrintManager still drives output': 'createPrintDocumentAdapter' in main and 'printManager.print' in main,
    'No Android print permission added': 'android.permission.PRINT' not in manifest,
    'Camera safe-area patch retained': 'esiswa-native-camera-safe-area' in main and '--esiswa-native-nav-bottom' in main,
    'Existing v1.1.3 responsive behavior retained': 'MOBILE_PAGE_SCALE = 0.88' in main and 'setTextZoom(96)' in main,
}

for name, ok in checks.items():
    print(('PASS' if ok else 'FAIL') + ' - ' + name)
failed = [name for name, ok in checks.items() if not ok]
if failed:
    print(f'FAIL {len(failed)}/{len(checks)} checks failed')
    sys.exit(1)
print(f'PASS {len(checks)}/{len(checks)} checks')
