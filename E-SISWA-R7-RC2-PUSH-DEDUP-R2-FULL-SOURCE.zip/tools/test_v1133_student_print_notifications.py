from pathlib import Path
import re, sys

ROOT=Path(__file__).resolve().parents[1]
main=(ROOT/'app/src/main/java/id/sch/smpn4dumai/esiswa/MainActivity.java').read_text()
push=(ROOT/'app/src/main/java/id/sch/smpn4dumai/esiswa/PushMessagingService.java').read_text()
gradle=(ROOT/'app/build.gradle').read_text()
checks=[]
def ck(name, cond): checks.append((name, bool(cond)))

ck('version lineage 1.1.3.x code >=8', bool(re.search(r"versionCode\s+(?:8|9|1[0-9]+)", gradle)) and bool(re.search(r"versionName\s+'1\.1\.3(?:\.[0-9]+){0,2}'", gradle)))
ck('print request uses lightweight first stage', "action:'print'" in main and 'lightRequest()' in main and "window.ESISWAPrintNative.postMessage(lightRequest())" in main)
ck('print request parsed structurally', 'parseNativePrintRequest' in main and 'PrintRequestData' in main)
ck('live WebView print remains primary', 'source.createPrintDocumentAdapter' in main)
ck('snapshot print fallback exists', 'startSnapshotPrint' in main and 'requestSnapshotFallback' in main)
ck('snapshot uses base url html', 'loadDataWithBaseURL' in main)
ck('snapshot waits for page finished', 'SnapshotPrintWebViewClient' in main and 'onPageFinished' in main)
ck('snapshot cleanup exists', 'destroySnapshotPrintWebView' in main)
ck('native notification mirror listener exists', 'ESISWANotifyNative' in main and 'configureNativeNotificationMirror' in main)
ck('notification mirror observes bell changes', 'MutationObserver' in main and ('fa-bell' in main or 'globalNotificationBadgeR535244' in main))
ck('notification mirror sends count', 'notifyCount' in main)
ck('android mirror posts local notification', 'showMirroredWebNotification' in main and 'PushMessagingService.showLocalNotification' in main)
ck('web mirror state dedupe exists', 'esiswa_web_notification_state' in main and 'last_web_badge_count' in main)
ck('push service exposes shared local notification', 'public static void showLocalNotification' in push)
ck('camera safe-area retained', 'applyCameraPopupSafeArea' in main and 'resolveNavigationBarHeight' in main)
ck('POST_NOTIFICATIONS retained', 'Manifest.permission.POST_NOTIFICATIONS' in main)
ck('FCM bridge retained', 'ESISWAAndroidPush' in main and 'FirebaseMessaging' in main)

bad=[]
for n,ok in checks:
    print(('PASS' if ok else 'FAIL'), '|', n)
    if not ok: bad.append(n)
print(f'SUMMARY: {len(checks)-len(bad)}/{len(checks)} PASS; failures={len(bad)}')
sys.exit(1 if bad else 0)
