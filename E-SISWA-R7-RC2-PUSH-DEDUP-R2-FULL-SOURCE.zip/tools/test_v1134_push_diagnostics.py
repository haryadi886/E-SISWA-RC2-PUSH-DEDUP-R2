from pathlib import Path
root=Path(__file__).resolve().parents[1]
main=(root/"app/src/main/java/id/sch/smpn4dumai/esiswa/MainActivity.java").read_text(encoding="utf-8")
gradle=(root/"app/build.gradle").read_text(encoding="utf-8")
checks={
    "versionCode 9+":"versionCode 9" in gradle or "versionCode 10" in gradle or "versionCode 11" in gradle or "versionCode 12" in gradle,
    "versionName 1.1.3.4+":"versionName '1.1.3.4'" in gradle or "versionName '1.1.3.5'" in gradle or "versionName '1.1.3.5.1'" in gradle or "versionName '1.1.3.5.2'" in gradle,
    "manual FCM refresh bridge":"requestFcmTokenRefresh" in main,
    "native push diagnostic bridge":"getNativePushStatus" in main,
    "permission diagnostic":"permissionGranted" in main and "POST_NOTIFICATIONS" in main,
    "channel diagnostic":"attendanceChannelEnabled" in main and "CHANNEL_ATTENDANCE" in main,
    "post-config retry":"postDelayed(MainActivity.this::refreshFcmToken, 1500)" in main,
}
for k,v in checks.items(): print(("PASS" if v else "FAIL"), k)
if not all(checks.values()): raise SystemExit(1)
print(f"SUMMARY: {sum(checks.values())}/{len(checks)} PASS")
